<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Anak</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <?php if(empty($child) || empty($histories)): ?>
        <p>Data tidak tersedia</p>
    <?php else: ?>
        <h1>Riwayat <?php echo e($child->nama); ?></h1>
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Makan</th>
                    <th>Susu</th>
                    <th>Air Putih</th>
                    <th>BAK</th>
                    <th>BAB</th>
                    <th>Tidur</th>
                    <th>Kondisi Anak</th>
                    <th>Kegiatan Outdoor</th>
                    <th>Kegiatan Indoor</th>
                    <th>Obat</th>
                    <th>Makanan Camilan</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($history->tanggal)->format('d/m/Y')); ?></td>
                        <td>
                            Pagi: <?php echo e($history->makan_pagi ?? 'Belum'); ?><br>
                            Siang: <?php echo e($history->makan_siang ?? 'Belum'); ?><br>
                            Sore: <?php echo e($history->makan_sore ?? 'Belum'); ?>

                        </td>
                        <td>
                            Pagi: <?php echo e($history->susu_pagi ?? '-'); ?> ml<br>
                            Siang: <?php echo e($history->susu_siang ?? '-'); ?> ml<br>
                            Sore: <?php echo e($history->susu_sore ?? '-'); ?> ml
                        </td>
                        <td>
                            Pagi: <?php echo e($history->air_putih_pagi ?? '-'); ?> ml<br>
                            Siang: <?php echo e($history->air_putih_siang ?? '-'); ?> ml<br>
                            Sore: <?php echo e($history->air_putih_sore ?? '-'); ?> ml
                        </td>
                        <td>
                            Pagi: <?php echo e($history->bak_pagi ?? '-'); ?> X<br>
                            Siang: <?php echo e($history->bak_siang ?? '-'); ?> X<br>
                            Sore: <?php echo e($history->bak_sore ?? '-'); ?> X
                        </td>
                        <td>
                            Pagi: <?php echo e($history->bab_pagi ?? '-'); ?> X<br>
                            Siang: <?php echo e($history->bab_siang ?? '-'); ?> X<br>
                            Sore: <?php echo e($history->bab_sore ?? '-'); ?> X
                        </td>
                        <td>
                            Pagi: <?php echo e($history->tidur_pagi ?? '-'); ?> X<br>
                            Siang: <?php echo e($history->tidur_siang ?? '-'); ?> X<br>
                            Sore: <?php echo e($history->tidur_sore ?? '-'); ?> X
                        </td>
                        <td><?php echo e($history->kondisi ?? '-'); ?></td>
                        <td>
                            <?php
                                $kegiatanOutdoor = json_decode($history->kegiatan_outdoor, true) ?? [];
                            ?>
                            <?php if(count($kegiatanOutdoor) > 0): ?>
                                <?php $__currentLoopData = $kegiatanOutdoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($kegiatan); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                $kegiatanIndoor = json_decode($history->kegiatan_indoor, true) ?? [];
                            ?>
                            <?php if(count($kegiatanIndoor) > 0): ?>
                                <?php $__currentLoopData = $kegiatanIndoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($kegiatan); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            Pagi: <?php echo e($history->obat_pagi ?? '-'); ?><br>
                            Siang: <?php echo e($history->obat_siang ?? '-'); ?><br>
                            Sore: <?php echo e($history->obat_sore ?? '-'); ?>

                        </td>
                        <td>
                            <?php
                                $camilanPagi = json_decode($history->makanan_camilan_pagi, true) ?? [];
                                $camilanSiang = json_decode($history->makanan_camilan_siang, true) ?? [];
                                $camilanSore = json_decode($history->makanan_camilan_sore, true) ?? [];
                            ?>
                            Pagi: <br>
                            <?php if(count($camilanPagi) > 0): ?>
                                <?php $__currentLoopData = $camilanPagi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($camilan); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                - <br>
                            <?php endif; ?>
                            Siang:<br>
                            <?php if(count($camilanSiang) > 0): ?>
                                <?php $__currentLoopData = $camilanSiang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($camilan); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                - <br>
                            <?php endif; ?>
                            Sore:<br>
                            <?php if(count($camilanSore) > 0): ?>
                                <?php $__currentLoopData = $camilanSore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    - <?php echo e($camilan); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                - <br>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($history->keterangan ?? 'Tidak ada'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/daycaredfi/resources/views/excel/excel_child_history.blade.php ENDPATH**/ ?>